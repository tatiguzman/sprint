<head>
  <meta charset="utf-8">
  <title>Kiona</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/integradorCss.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
</head>

<body>

 <header>
  <div class="redesEInicio">
    <div class="contenedor-header row justify-content-between">
      <ul class="follow col-12 col-sm-6 d-flex flex-row justify-content-center justify-content-sm-start">
        <li><a href="http://facebook.com" target="_blank"><img src="imagenes/facebookwhite.png" alt="Facebook"></a></li>
        <li><a href="http://twitter.com" target="_blank"><img src="imagenes/twittericon.png" alt="Twitter"></a></li>
        <li><a href="http://instagram.com" target="_blank"><img src="imagenes/instagram-logo-white.png" alt="Instagram"></a></li>
      </ul>
      <div class="iniciaSesion col-12 col-sm-6 text-white d-flex flex-row justify-content-sm-center justify-content-md-end"">
        <h4 class="text-sm-right"><a href="login">INICIA SESIÓN</a> o <a href="register">REGISTRATE</a></h4>
      </div>
    </div>
  </div>

  <div class="contenedor-header">
    <div class="buscar">
      <div class="elements-header">
        <input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="0" placeholder="Search" name="keyword" type="search" class="searchbar">
      </div>
      <!--<ul class="elements-header title-wrapper">
        <li>
          <img class= "Kiona" src="imagenes/kiona.png" alt="Kiona">
        </li>
      </ul>-->
      <h1 class="elements-header title-wrapper"><a href="home">Kiona</a></h1>

      <div class="elements-header icons-wrapper">
        <ul class="icons-header">
          <li>
            <img class= "Canasta" src="imagenes/canasta.png" alt="canasta">
          </li>
        </ul>

        <ul class="icons-header">
          <li>
            <img class= "Corazon" src="imagenes/corazon.png" alt="corazon">
          </li>
        </ul>
      </div>
    </div>
  </div>

  <nav class="culo">
    <div class="contenedor-header">
      <ul>
        <li><a href="home">HOME</a></a></li>
        <li><a href="productos">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas">FAQs</a></li>
      </ul>
    </div>
  </nav>

  <!--prueba nav-->
  <div class="pos-f-t nav-mobile">

    <nav class="navbar navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
    <div class="contenedor-header collapse" id="navbarToggleExternalContent">
      <ul>
        <li><a href="home.php">HOME</a></a></li>
        <li><a href="#">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas.php">FAQs</a></li>
      </ul>
    </div>

  </div>

</header>

@extends('layouts.app')


@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Login') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}" aria-label="{{ __('Login') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    {{ __('Forgot Your Password?') }}
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

</body>