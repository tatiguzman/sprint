<!DOCTYPE html>
<html>
 <head>
   <meta charset="utf-8">
   <title>Eliminar Producto</title>
 </head>
 <body>
   <h1>Eliminar producto</h1>
   <form class="" action="/products/delete" method="post">
     {{ csrf_field() }}
      <div class="form-group">
            <label for="productCode">Cod. Producto
              <input type="text" name="productCode" value="">
            </label>
      </div>
             
      <button type="submit" name="eliminar">Eliminar</button>

   </form>
   
   @if ($errors->any())
    <div>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }} </li>
            @endforeach
        </ul>
    </div>
   @endif
   
 </body>
</html>