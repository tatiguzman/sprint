  <!DOCTYPE html>
  <html>

  <head>
    <meta charset="utf-8">
    
    <title>Kiona Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="http://meyerweb.com/eric/tools/css/reset/reset.css">-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/integradorCss.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

  </head>

  <body>

    <header>
      <div class="redesEInicio">
        <div class="contenedor-header row justify-content-between">
          <ul class="follow col-12 col-sm-6 d-flex flex-row justify-content-center justify-content-sm-start">
            <li><a href="http://facebook.com" target="_blank"><img src="imagenes/facebookwhite.png" alt="Facebook"></a></li>
            <li><a href="http://twitter.com" target="_blank"><img src="imagenes/twittericon.png" alt="Twitter"></a></li>
            <li><a href="http://instagram.com" target="_blank"><img src="imagenes/instagram-logo-white.png" alt="Instagram"></a></li>
          </ul>
 
           <div class="iniciaSesion col-12 col-sm-6 text-white d-flex flex-row justify-content-sm-center justify-content-md-end">
              <h4><a href="login">INICIA SESIÓN</a> o <a href="register">REGISTRATE</a></h4>
            </div>
        </div>
      </div>
         

      <div class="contenedor-header">
        <div class="buscar">
          <div class="elements-header">
            <input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="0" placeholder="Search" name="keyword" type="search" class="searchbar">
          </div>
          <!--<ul class="elements-header title-wrapper">
            <li>
              <img class= "Kiona" src="imagenes/kiona.png" alt="Kiona">
            </li>
          </ul>-->
          <h1 class="elements-header title-wrapper"><a href="home">Kiona</a></h1>

          <div class="elements-header icons-wrapper">
            <ul class="icons-header">
              <li>
                <img class= "Canasta" src="imagenes/canasta.png" alt="canasta">
              </li>
            </ul>

            <ul class="icons-header">
              <li>
                <img class= "Corazon" src="imagenes/corazon.png" alt="corazon">
              </li>
            </ul>
          </div>
        </div>
      </div>

      <nav class="culo">
        <div class="contenedor-header">
          <ul>
            <li><a href="home">HOME</a></a></li>
            <li><a href="product">TIENDA</a></li>
            <li><a href="#">NOVEDADES</a></li>
            <li><a href="#">MARCAS</a></li>
            <li><a href="#">EVENTOS</a></li>
            <li><a href="preguntas">FAQs</a></li>
          </ul>
        </div>
      </nav>

      <!--Navegacion collapse-->
      <div class="pos-f-t nav-mobile">

        <nav class="navbar navbar-light bg-light">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </nav>
        <div class="contenedor-header collapse text-black" id="navbarToggleExternalContent">
          <ul>
            <li><a href="home">HOME</a></a></li>
            <li><a href="products.product">TIENDA</a></li>
            <li><a href="#">NOVEDADES</a></li>
            <li><a href="#">MARCAS</a></li>
            <li><a href="#">EVENTOS</a></li>
            <li><a href="preguntas">FAQs</a></li>
          </ul>
        </div>
        
      </div>

    </header>

  <div class="container">

    <div>
        <a href="/products/create">Nuevo Producto</a>
    </div><br>

    <div>
        <a href="/products/delete">Eliminar Producto</a>
    </div><br>

  	 <main>
        <section class="linea">
          <h1>REMERAS</h1>
        </section>

         <section class="columnas">
            <div class="columna">
                <div class="card" style="width: 300px;">
                    <img class="card-img-top" src="imgs/remeras/paz.png" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">Remera Paz</h5>
                      <p class="card-text">$650</p>
                      <a href="#" class="btn btn-primary">Agregar al carrito</a>
                    </div>
                </div>
            </div>
          <div class="columna">
              <div class="card" style="width: 300px;">
                  <img class="card-img-top" src="imgs/remeras/botones.png" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Remera Calu</h5>
                    <p class="card-text">$790</p>
                    <a href="#" class="btn btn-primary">Agregar al carrito</a>
                  </div>
              </div>
          </div>
           <div class="columna">
              <div class="card" style="width: 300px;">
                  <img class="card-img-top" src="imgs/remeras/moniosn.png" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Top Niza</h5>
                    <p class="card-text">$820</p>
                    <a href="#" class="btn btn-primary">Agregar al carrito</a>
                  </div>
              </div>
          </div>
        </section>

       
        <section class="linea">
            <h1>SWEATERS</h1>
          </section>

          <section class="columnas">
              <div class="columna">
                  <div class="card" style="width: 300px;">
                      <img class="card-img-top" src="imgs/sweaters/blanco.png" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Sweater Capri</h5>
                        <p class="card-text">$1.540</p>
                        <a href="#" class="btn btn-primary">Agregar al carrito</a>
                      </div>
                  </div>
              </div>
            <div class="columna">
                <div class="card" style="width: 300px;">
                    <img class="card-img-top" src="imgs/sweaters/botones.png" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">Sweater Neo</h5>
                      <p class="card-text">$1.400</p>
                      <a href="#" class="btn btn-primary">Agregar al carrito</a>
                    </div>
                </div>
            </div>
             <div class="columna">
                <div class="card" style="width: 300px;">
                    <img class="card-img-top" src="imgs/sweaters/escotev.png" alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">Sweater Chao</h5>
                      <p class="card-text">$1.700</p>
                      <a href="#" class="btn btn-primary">Agregar al carrito</a>
                    </div>
                </div>
            </div>
          </section>
    
         

          <section class="linea">
              <h1>VESTIDOS</h1>
            </section>
    
            <section class="columnas">
                <div class="columna">
                    <div class="card" style="width: 300px;">
                        <img class="card-img-top" src="imgs/vestidos/rayado.png" alt="Card image cap">
                        <div class="card-body">
                          <h5 class="card-title">Vestido Marina</h5>
                          <p class="card-text">$990</p>
                          <a href="#" class="btn btn-primary">Agregar al carrito</a>
                        </div>
                    </div>
                </div>
              <div class="columna">
                  <div class="card" style="width: 300px;">
                      <img class="card-img-top" src="imgs/vestidos/rosa.png" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Vestido Pomelo</h5>
                        <p class="card-text">$1.090</p>
                        <a href="#" class="btn btn-primary">Agregar al carrito</a>
                      </div>
                  </div>
              </div>
               <div class="columna">
                  <div class="card" style="width: 300px;">
                      <img class="card-img-top" src="imgs/vestidos/rojo.png" alt="Card image cap">
                      <div class="card-body">
                        <h5 class="card-title">Vestido Pasión</h5>
                        <p class="card-text">$1.150</p>
                        <a href="#" class="btn btn-primary">Agregar al carrito</a>
                      </div>
                  </div>
              </div>
            </section>
      
            
              <section class="linea">
                  <h1>PANTALONES</h1>
                </section>
        
                <section class="columnas">
                    <div class="columna">
                        <div class="card" style="width: 300px;">
                            <img class="card-img-top" src="imgs/pantalones/botones.png" alt="Card image cap">
                            <div class="card-body">
                              <h5 class="card-title">Pantalón Star</h5>
                              <p class="card-text">$1.800</p>
                              <a href="#" class="btn btn-primary">Agregar al carrito</a>
                            </div>
                        </div>
                    </div>
                  <div class="columna">
                      <div class="card" style="width: 300px;">
                          <img class="card-img-top" src="imgs/pantalones/gris.png" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title">Pantalón Nube</h5>
                            <p class="card-text">$1.760</p>
                            <a href="#" class="btn btn-primary">Agregar al carrito</a>
                          </div>
                      </div>
                  </div>
                   <div class="columna">
                      <div class="card" style="width: 300px;">
                          <img class="card-img-top" src="imgs/pantalones/negro.png" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title">Pantalón London</h5>
                            <p class="card-text">$1.920</p>
                            <a href="#" class="btn btn-primary">Agregar al carrito</a>
                          </div>
                      </div>
                  </div>
                </section>

                <section class="linea">
                    <h1>ZAPATOS</h1>
                  </section>
          
                  <section class="columnas">
                      <div class="columna">
                          <div class="card" style="width: 300px;">
                              <img class="card-img-top" src="imgs/zapatos/amarilla.png" alt="Card image cap">
                              <div class="card-body">
                                <h5 class="card-title">Sandalia Sinvestre</h5>
                                <p class="card-text">$2.800</p>
                                <a href="#" class="btn btn-primary">Agregar al carrito</a>
                              </div>
                          </div>
                      </div>
                    <div class="columna">
                        <div class="card" style="width: 300px;">
                            <img class="card-img-top" src="imgs/zapatos/botas.png" alt="Card image cap">
                            <div class="card-body">
                              <h5 class="card-title">Botas Jackson</h5>
                              <p class="card-text">$2.760</p>
                              <a href="#" class="btn btn-primary">Agregar al carrito</a>
                            </div>
                        </div>
                    </div>
                     <div class="columna">
                        <div class="card" style="width: 300px;">
                            <img class="card-img-top" src="imgs/zapatos/griega.png" alt="Card image cap">
                            <div class="card-body">
                              <h5 class="card-title">Sandalias Creta</h5>
                              <p class="card-text">$2.920</p>
                              <a href="#" class="btn btn-primary">Agregar al carrito</a>
                            </div>
                        </div>
                    </div>
                  </section>  
      </main>
  </div>  

  <footer class="footer-end">
  <p class="text-center"> Copyright 2018 - Todos los Derechos Reservados </p>
</footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>  
  </body>

  </html>