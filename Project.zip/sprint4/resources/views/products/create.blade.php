<!DOCTYPE html>
<html>
 <head>
   <meta charset="utf-8">
   <title>Agregar Producto</title>
 </head>
 <body>
   <h1>Agregar producto</h1>
   <form class="" action="/products" method="post">
     {{ csrf_field() }}
      <div class="form-group">
            <label for="productCode">Cod. Producto
              <input type="text" name="productCode" value="">
            </label>
      </div>
     <div class="form-group">
       <label for="producto">Nombre
         <input type="text" name="productName" value="">
       </label>
     </div>
     <div class="form-group">
       <label for="productLine">Linea</label>
       <select class="form-control" name="productLine">
         <option value="Remeras">Remeras</option>
         <option value="Pantalones">Pantalones</option>
         <option value="Camperas">Camperas</option>
       </select>
     </div>
    
     <div class="form-group">
       <label for="ruta">ruta</label>
       <input type="text" name="productSource" value="">
     </div>
     <div class="form-group">
       <label for="precio">Precio</label>
       <input type="number" name="productPrice" value="">
     </div>
         
      <button type="submit" name="agregar">Agregar</button>

   </form>
   
   @if ($errors->any())
    <div>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }} </li>
            @endforeach
        </ul>
    </div>
   @endif
   
 </body>
</html>