<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  
  <title>Kiona Page</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--<link rel="stylesheet" href="http://meyerweb.com/eric/tools/css/reset/reset.css">-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/integradorCss.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

</head>

<body>
 <header>
  <div class="redesEInicio">
    <div class="contenedor-header row justify-content-between">
      <ul class="follow col-12 col-sm-6 d-flex flex-row justify-content-center justify-content-sm-start">
        <li><a href="http://facebook.com" target="_blank"><img src="imagenes/facebookwhite.png" alt="Facebook"></a></li>
        <li><a href="http://twitter.com" target="_blank"><img src="imagenes/twittericon.png" alt="Twitter"></a></li>
        <li><a href="http://instagram.com" target="_blank"><img src="imagenes/instagram-logo-white.png" alt="Instagram"></a></li>
      </ul>

           @if (Route::has('login'))
                <div class="iniciaSesion col-12 col-sm-6 text-white d-flex flex-row justify-content-sm-center justify-content-md-end">
                    @auth
                        <a href="{{ route('logout') }}" id="logout">logout</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                  </div>
            @endif
    </div>
  </div>
      

  <div class="contenedor-header">
    <div class="buscar">
      <div class="elements-header">
        <input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="0" placeholder="Search" name="keyword" type="search" class="searchbar">
      </div>
      <!--<ul class="elements-header title-wrapper">
        <li>
          <img class= "Kiona" src="imagenes/kiona.png" alt="Kiona">
        </li>
      </ul>-->
      <h1 class="elements-header title-wrapper"><a href="home">Kiona</a></h1>

      <div class="elements-header icons-wrapper">
        <ul class="icons-header">
          <li>
            <img class= "Canasta" src="imagenes/canasta.png" alt="canasta">
          </li>
        </ul>

        <ul class="icons-header">
          <li>
            <img class= "Corazon" src="imagenes/corazon.png" alt="corazon">
          </li>
        </ul>
      </div>
    </div>
  </div>

  <nav class="culo">
    <div class="contenedor-header">
      <ul>
        <li><a href="home">HOME</a></a></li>
        <li><a href="product">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas">FAQs</a></li>
      </ul>
    </div>
  </nav>

  <!--Navegacion collapse-->
  <div class="pos-f-t nav-mobile">

    <nav class="navbar navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
    <div class="contenedor-header collapse text-black" id="navbarToggleExternalContent">
      <ul>
        <li><a href="home">HOME</a></a></li>
        <li><a href="product">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas">FAQs</a></li>
      </ul>
    </div>
    
  </div>

</header>

<div class="container">
  <div>
    <div class="contenedor-header">
      <a href="#" target="_blank"><img class="banner-img" src= imagenes/cluse.jpg alt="Cluse"></a>
    </div>
  </div>
  <!--Reemplazo carousel-->
  <h1 class="text-center pt-3"> NEW IN! </h1>
  <div id="carouselimagenes" class="carousel slide mt-3 mb-3" data-ride="carousel" data-interval="2000">
    <ol class="carousel-indicators">
      <li data-target="#carouselimagenes" data-slide-to="0" class="active"></li>
      <li data-target="#carouselimagenes" data-slide-to="1"></li>
      <li data-target="#carouselimagenes" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active" >
          <img class=" mw-100 h-auto img-fluid" src="imagenes/carousel-1.jpg" alt="First slide">
      </div>
      <div class="carousel-item">
          <img class=" mw-100 h-auto img-fluid" src="imagenes/carousel-2.jpg" alt="Second slide">
      </div>
      <div class="carousel-item">
          <img class=" mw-100 h-auto img-fluid" src="imagenes/carousel-3.jpg" alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselimagenes" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselimagenes" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <div class="row d-flex justify-content-md-between mb-3">
    <div class="col-xs-12 col-md-6" >
      <a href="#" target="_blank">
        <img class="img-fluid w-100" src= "imagenes/allsaints.jpg" alt="AllSaints">
      </a>
    </div>

    <div class="col-xs-12 col-md-6" >
      <a href="#" target="_blank">
        <img class="img-fluid w-100" src= "imagenes/allsaintss.jpg" alt="AllSaints">
      </a>
    </div>
  </div>

</div>

<footer class="footer-end">
  <p class="text-center"> Copyright 2018 - Todos los Derechos Reservados </p>
</footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
