<?php
//require_once "funciones.php";
//require_once "validaciones.php";
//require_once "clases/usuario.php";




if (isset($_POST["submitted"])) {
  $user = ['username'=> $_POST['usuario'],
            'password' => $_POST['contrasena']];

  $resultado= Usuario::buscarYValidarUsuario($user['username'],$user['password']);
    //var_dump($resultado);
    if($resultado ==true){
      session_start([
        "cookie_lifetime" => time()+3600
      ]);
      $_SESSION["username"]=$user['username'];

      header("Location: bienvenido.php");

    } else {
      $errores= ["Error de usuario o contraseña"];
    }
  
}


?>


<!doctype html>

<head>
  <meta charset="utf-8">
  <title>Kiona</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/integradorCss.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
</head>

<body>

 <header>
  <div class="redesEInicio">
    <div class="contenedor-header row justify-content-between">
      <ul class="follow col-12 col-sm-6 d-flex flex-row justify-content-center justify-content-sm-start">
        <li><a href="http://facebook.com" target="_blank"><img src="imagenes/facebookwhite.png" alt="Facebook"></a></li>
        <li><a href="http://twitter.com" target="_blank"><img src="imagenes/twittericon.png" alt="Twitter"></a></li>
        <li><a href="http://instagram.com" target="_blank"><img src="imagenes/instagram-logo-white.png" alt="Instagram"></a></li>
      </ul>
      <div class="iniciaSesion col-12 col-sm-6 text-white d-flex flex-row justify-content-sm-center justify-content-md-end"">
        <h4 class="text-sm-right"><a href="login">INICIA SESIÓN</a> o <a href="register">REGISTRATE</a></h4>
      </div>
    </div>
  </div>

  <div class="contenedor-header">
    <div class="buscar">
      <div class="elements-header">
        <input autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="0" placeholder="Search" name="keyword" type="search" class="searchbar">
      </div>
      <!--<ul class="elements-header title-wrapper">
        <li>
          <img class= "Kiona" src="imagenes/kiona.png" alt="Kiona">
        </li>
      </ul>-->
      <h1 class="elements-header title-wrapper"><a href="home">Kiona</a></h1>

      <div class="elements-header icons-wrapper">
        <ul class="icons-header">
          <li>
            <img class= "Canasta" src="imagenes/canasta.png" alt="canasta">
          </li>
        </ul>

        <ul class="icons-header">
          <li>
            <img class= "Corazon" src="imagenes/corazon.png" alt="corazon">
          </li>
        </ul>
      </div>
    </div>
  </div>

  <nav class="culo">
    <div class="contenedor-header">
      <ul>
        <li><a href="home">HOME</a></a></li>
        <li><a href="productos">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas">FAQs</a></li>
      </ul>
    </div>
  </nav>

  <!--prueba nav-->
  <div class="pos-f-t nav-mobile">

    <nav class="navbar navbar-light bg-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
    <div class="contenedor-header collapse" id="navbarToggleExternalContent">
      <ul>
        <li><a href="home.php">HOME</a></a></li>
        <li><a href="#">TIENDA</a></li>
        <li><a href="#">NOVEDADES</a></li>
        <li><a href="#">MARCAS</a></li>
        <li><a href="#">EVENTOS</a></li>
        <li><a href="preguntas.php">FAQs</a></li>
      </ul>
    </div>

  </div>

</header>

<!--ACA EMPIEZA EL LOGIN Y REGISTRO-->
<div class="container">

    <div class="row ">
     <?php if ($_POST && huboErrores($errores)) : ?>
      <div class="col-sm-12 alert alert-danger">
        <ul>
          <?php foreach($errores as $bolsaDeErrores) : ?>
              <li><?= $bolsaDeErrores ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
  </div>

  <div class="row d-flex justify-content-center login">
    <h3 class="col-12 text-center">Inicia Sesión</h3>
    <form role="form" action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label>Usuario</label>
        <input type="text" class="form-control" name="usuario" value="<?= isset($_POST['usuario'])?$_POST['usuario']:""; ?>" placeholder="Ingrese usuario">
        
      </div>
      <div class="form-group">
        <label>Contraseña</label>
        <input type="password" class="form-control" name="contrasena" placeholder="Contraseña">
      </div>
      <!--data-toggle="modal" data-target="#mymodal"-->
      <button type="submit" name="submitted" >Login</button>
      <label><input type="checkbox" name="recuerdame" value='1'> Recuerdame</label>
      <p>Olvidaste tu constraseña? <a href="#">Click acá.</a></p>
    </form>

  </div>

</div>


<footer class="footer-end">
  <div class="container">
    <p class="text-center"> Copyright 2018 - Todos los Derechos Reservados </p>
  </div>
</footer>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>
