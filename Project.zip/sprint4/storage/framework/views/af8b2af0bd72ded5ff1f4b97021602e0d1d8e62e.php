<!DOCTYPE html>
<html>
 <head>
   <meta charset="utf-8">
   <title>Agregar Producto</title>
 </head>
 <body>
   <h1>Agregar producto</h1>
   <form class="" action="/products" method="post">
     <?php echo e(csrf_field()); ?>

      <div class="form-group">
            <label for="productCode">Cod. Producto
              <input type="text" name="productCode" value="">
            </label>
      </div>
     <div class="form-group">
       <label for="producto">Nombre
         <input type="text" name="productName" value="">
       </label>
     </div>
     <div class="form-group">
       <label for="productLine">Linea</label>
       <select class="form-control" name="productLine">
         <option value="Remeras">Remeras</option>
         <option value="Pantalones">Pantalones</option>
         <option value="Camperas">Camperas</option>
       </select>
     </div>
    
     <div class="form-group">
       <label for="ruta">ruta</label>
       <input type="text" name="productSource" value="">
     </div>
     <div class="form-group">
       <label for="precio">Precio</label>
       <input type="number" name="productPrice" value="">
     </div>
         
      <button type="submit" name="agregar">Agregar</button>

   </form>
   
   <?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>
   
 </body>
</html>