<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $products = Product::paginate(10); 

        return view('products.index', [
            'products' => $products
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         return view('products.create');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $this->validate($request, [
            'productCode' => 'required',
            'productName' => 'required',
            'productLine' => 'required',
            /*'productScale' => 'required',*/
            'productPrice' => 'required|numeric',
            /*'quantityInStock' => 'required|numeric',
            'productVendor' => 'required',*/
            'productSource' => 'required',
            /*'MSRP' => 'required|numeric'*/
        ]);

        $product = Product::create([
            'productCode' => $request->input('productCode'),
            'productName' => $request->input('productName'),
            'productLine' => $request->input('productLine'),
            /*'productScale' => $request->input('productScale'),*/
            'productPrice' => $request->input('productPrice'),
            /*'quantityInStock' => $request->input('quantityInStock'),
            'productVendor' => $request->input('productVendor'),*/
            'productSource' => $request->input('productSource'),
            /*'MSRP' => $request->input('MSRP')*/
        ]);

        return "Todo bien!";
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $productCode)
    {
        $product = Product::find($productCode);
        
        $product->delete();

        return "Todo bien!";
    }
}
